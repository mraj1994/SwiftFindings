import UIKit

var greeting = "Hello, playground"



//create a thread safe singleton class using dispatch barrier

struct User {
    let name: String
    var accountDetails: AccountDetails?
}

struct AccountDetails {
    let accountNumber: String
    var balance: Double
}



class UserBankingDetailSingleton {
    static let shared = UserBankingDetailSingleton()
    private init() {}
    
    private var user: User?
    
    private let taskHandlerQueue = DispatchQueue(label: "Transaction Handler queue", attributes: .concurrent)
    
    func makeTransactionOf(amount: Double) {
        taskHandlerQueue.async(flags: .barrier) {
            sleep(3)
            if var user = self.user {
                if var balance = user.accountDetails?.balance, balance > amount {
                    balance -= amount
                    user.accountDetails?.balance = balance
                    self.user = user
                    print("Transaction of \(amount) is successfull. Updated balance is \(balance)")
                } else {
                    print("Transaction was declined due to insufficent balance")
                }
            }
        }
    }
    
    func addMoney(amount: Double) {
        taskHandlerQueue.async(flags: .barrier) {
            sleep(10)
            if var user = self.user {
                user.accountDetails?.balance += amount
                self.user = user
                print("Added \(amount) to your account. Updated balance is \(user.accountDetails?.balance ?? 0)")
            }
        }
    }
    
    func addUser(user: User){
        self.user = user
        debugPrint("User added with detail \(user)")
    }
}


let accountDetails = AccountDetails(accountNumber: "1234567890", balance: 1000)
let user = User(name: "Madhav", accountDetails: accountDetails)

UserBankingDetailSingleton.shared.addUser(user: user)
UserBankingDetailSingleton.shared.makeTransactionOf(amount: 550)
UserBankingDetailSingleton.shared.addMoney(amount: 550)
UserBankingDetailSingleton.shared.makeTransactionOf(amount: 550)
